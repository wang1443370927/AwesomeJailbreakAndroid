# Awesome Jailbreak LLMs — Android wrapper

This is a lightweight Android WebView app that opens the supplied GitHub repository.
The repository's source/content has not been inspected or copied into the app.

## Build an APK

1. Open this project in Android Studio (JDK 17; Android SDK Platform 35).
2. Run **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Or push the project to a GitHub repository and run **Actions → Build Android APK**.
The workflow uploads `app-debug.apk` as a downloadable workflow artifact.

## Notes

- This is an online WebView wrapper, not an offline/native conversion of the repository.
- Internet access is required.
- The debug APK is for testing/sideloading. For Play Store distribution, configure a release signing key.
